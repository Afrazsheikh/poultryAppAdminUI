export const environment = {
  production: true,
  //apiBaseUrl: 'https://foodinventoryuk.herokuapp.com/v1/'
  apiBaseUrl: 'https://foodinventorygerman.herokuapp.com/v1/'
};  
``