import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-declined-order',
  templateUrl: './declined-order.component.html',
  styleUrls: ['./declined-order.component.scss']
})
export class DeclinedOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
