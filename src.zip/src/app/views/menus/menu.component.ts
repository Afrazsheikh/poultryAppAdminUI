import { Component, OnInit } from '@angular/core';
import { MenuService } from '../../services/menu.service';
import { Router, NavigationExtras } from '@angular/router';
import { Subscriber } from 'rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {

  menus: any;
  restId: any = localStorage.getItem('restId');
  items: any;
  categories: any;
  toppingGroup: any;
  isLoading: boolean = true;
  options: any;
  toppings: any;
  item: any;
  addingCategory: any;
  addingOption: any;
  addingToppingGroup: any;
  addingTopping: any;
  selectedCategory: any;
  selectedOption: any;
  selectedTopping: any;
  selectedItem: any;
  addingItem: any;



  constructor(private menuService: MenuService,private router: Router)
  {

this.menuService.getItems(this.restId).subscribe((response) => {
  console.log(response);
  if(response.success) {

    this.isLoading = false;
    this.items = response.data;
  }
}, err => {
  console.log(err);
})

  this.addingCategory = new FormGroup({"name": new FormControl(null, [Validators.required]),
                                       "description": new FormControl(null) });

  this.addingOption = new FormGroup({"name": new FormControl(null, [Validators.required]) });

  this.addingTopping = new FormGroup({"name": new FormControl(null, [Validators.required]),
                                      "price": new FormControl(null, [Validators.required]) });


  }

  ngOnInit(): void {}

  getCategories()
  {
    this.menuService.getCategory(this.restId).subscribe((response) => {
      console.log(response);
      if(response.success) {
        this.categories = response.data;
        console.log(this.categories);
      }

     },
     (err) => {

      console.log(err);
    })

  }


  getToppingGroup() {
    this.menuService.getToppingGroup(this.restId).subscribe((response) => {
      console.log(response);
      if(response.success) {
        this.toppingGroup= response.data;
        console.log(this.toppingGroup);
      }

     },
     (err) => {

      console.log(err);
    })
  }

  getOption() {
    this.menuService.getOption(this.restId).subscribe((response) => {
      console.log(response);
      if(response.success) {
        this.options= response.data;
        console.log(this.options);
      }

     },
     (err) => {

      console.log(err);
    })
  }

  getTopping() {
    this.menuService.getTopping(this.restId).subscribe((response) => {
      console.log(response);
      if(response.success) {
        this.toppings= response.data;
        console.log(this.toppings);
      }

     },
     (err) => {

      console.log(err);
    })
  }

  addItem() {
    this.menuService.addItem(this.restId, this.addingItem.value).subscribe((response) => {
      if(response.success) {
        console.log(response);
      }

     },
     (err) => {

      console.log(err);
    })
  }

  updateItem() {
    this.menuService.updateItem(this.restId).subscribe((response) => {
      console.log(response);
      if(response.success) {
        this.item= response.data;
        console.log(this.item);
      }

     },
     (err) => {

      console.log(err);
    })
  }

  addTopping() {
    this.menuService.addTopping(this.restId, this.addingTopping.value).subscribe((response) => {
      if(response.success) {
        console.log(response);
      }

     },
     (err) => {

      console.log(err);
    })
  }

  addOption() {
    this.menuService.addOption(this.restId, this.addingOption.value).subscribe((response) => {
      if(response.success) {
        console.log(response);
      }

     },
     (err) => {

      console.log(err);
    })
  }

  addToppingGroup() {
    this.menuService.addToppingGroup(this.restId, this.addingToppingGroup.value).subscribe((response) => {
      if(response.success) {
        console.log(response);
      }

     },
     (err) => {

      console.log(err);
    })
  }

  addCategory() {

    this.menuService.addCategory(this.restId, this.addingCategory.value).subscribe((response) => {
      if(response.success) {
        console.log(response);
      }

     },
     (err) => {

      console.log(err);
    })
   }

   setSelectedCategory(index) {

     this.selectedCategory = this.categories[index];
     console.log(this.selectedCategory)
   }

   setSelectedOption(index) {

    this.selectedOption = this.options[index];
    console.log(this.selectedOption)
  }

  setSelectedTopping(index) {

    this.selectedTopping = this.toppings[index];
    console.log(this.selectedTopping)
  }

  editItemList(index) {
    this.selectedItem = this.items[index];
    console.log(this.selectedItem)
  }

}
