import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DeclinedOrderRoutingModule } from './declined-order-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DeclinedOrderRoutingModule
  ]
})
export class DeclinedOrderModule { }
